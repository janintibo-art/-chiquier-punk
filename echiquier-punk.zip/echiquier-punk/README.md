# Échiquier Punk

Le code de ton échiquier 3D, organisé en projet, prêt à devenir une application Android (APK).
Pas besoin d'être développeur : la fabrication de l'APK se fait toute seule sur GitHub.

---

## Ce qu'il y a dans le dossier

```
echiquier-punk/
├── www/                    ← le jeu (la partie web)
│   ├── index.html          ← la page du jeu
│   ├── css/style.css       ← l'apparence
│   ├── js/game.js          ← tout le code du jeu
│   └── assets/
│       ├── tiles/          ← tes 2 dalles (déjà incluses)
│       ├── pieces/         ← tes 12 personnages .glb (à venir — voir le fichier dedans)
│       └── cards/          ← tes cartes punk (plus tard)
├── package.json            ← configuration de l'appli
├── capacitor.config.json   ← nom et identité de l'appli
└── .github/workflows/      ← la "recette" qui fabrique l'APK sur GitHub
```

---

## 1) Tester le jeu sur ton ordinateur (facultatif)

Le plus simple, avec Node.js (https://nodejs.org) installé :

1. Ouvre un terminal dans ce dossier.
2. Tape : `npx serve www`
3. Ouvre l'adresse affichée (ex. http://localhost:3000) dans ton navigateur.

> Astuce : si tu ouvres `www/index.html` en double-cliquant, le jeu marche mais le plateau
> affiche un marbre par défaut au lieu de tes dalles. C'est normal — il faut un petit serveur
> pour charger les images. La commande ci-dessus s'en occupe.

---

## 2) Fabriquer l'APK sur GitHub (le but)

1. Crée un compte gratuit sur https://github.com
2. Crée un nouveau dépôt (bouton **New repository**), nomme-le par ex. `echiquier-punk`.
3. Envoie tout le contenu de ce dossier dedans :
   - soit avec **Add file → Upload files** (glisse les fichiers/dossiers),
   - soit avec `git` si tu connais.
4. Va dans l'onglet **Actions** du dépôt. La tâche **Build APK** se lance automatiquement.
   (Sinon, clique sur "Build APK" puis sur **Run workflow**.)
5. Attends quelques minutes. Quand la coche est **verte ✅**, ouvre la tâche terminée et
   télécharge l'APK dans la section **Artifacts** (tout en bas de la page).
6. Copie ce fichier `.apk` sur ton téléphone Android et installe-le
   (autorise "installer depuis une source inconnue" si on te le demande).

> ⚠️ La toute première compilation peut parfois échouer pour un petit détail technique
> (versions d'outils, licences Android). Si ça arrive, **copie-moi le message d'erreur**
> affiché dans l'onglet Actions et je te corrige le fichier `.github/workflows/build-apk.yml`.

---

## 3) Ajouter tes personnages 3D (prochaine étape, ensemble)

Le dossier `www/assets/pieces/` est prêt à recevoir tes 12 personnages `.glb`
(voir les noms exacts dans `_LISEZ-MOI.txt` à l'intérieur).
On branchera ensuite le jeu pour qu'il charge tes personnages animés à la place
des pièces stylisées — avec la marche, l'attaque et la chute.

---

## 4) Changer les dalles

Tes dalles sont déjà dans `www/assets/tiles/` (`claire.png` et `sombre.png`).
Pour les changer, remplace simplement ces deux fichiers (garde les mêmes noms).

---

## L'état du jeu aujourd'hui

- Plateau 3D avec tes dalles ✅
- 32 pièces, déplacements corrects par pièce, captures, tour par tour ✅
- Commande tactile (toucher pour jouer, glisser/pincer pour la vue) ✅
- À venir : tes personnages animés, le Mode Punk, et les règles fines
  (échec, mat, roque, prise en passant).
