/* ============================================================
   ÉCHIQUIER PUNK — moteur du jeu (three.js r128)
   - plateau 8x8 : charge tes dalles depuis assets/tiles/ (sinon marbre)
   - 32 pièces 3D stylisées (à remplacer plus tard par tes personnages .glb)
   - règles de déplacement par pièce, captures, tour par tour
   - tap-to-move (mobile) + caméra orbitale tactile
   ============================================================ */

const EP = 0.16;            // épaisseur des dalles -> dessus à y=EP

const renderer = new THREE.WebGLRenderer({ antialias:true, alpha:true });
renderer.setSize(innerWidth, innerHeight);
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
document.body.appendChild(renderer.domElement);
const maxAniso = renderer.capabilities.getMaxAnisotropy();

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(44, innerWidth/innerHeight, 0.1, 100);
const clock = new THREE.Clock();

scene.add(new THREE.HemisphereLight(0xc7ccff, 0x1b1b22, 0.95));
const dir = new THREE.DirectionalLight(0xffffff, 0.85);
dir.position.set(-5,12,6); dir.castShadow=true; dir.shadow.mapSize.set(2048,2048);
Object.assign(dir.shadow.camera,{left:-8,right:8,top:8,bottom:-8,near:1,far:34}); dir.shadow.bias=-0.0004;
scene.add(dir);

/* ---------- Dalles ---------- */
function marble(base,vein){
  const c=document.createElement('canvas'); c.width=c.height=512; const x=c.getContext('2d');
  x.fillStyle=base; x.fillRect(0,0,512,512);
  for(let i=0;i<9000;i++){ x.fillStyle=`rgba(255,255,255,${Math.random()*0.03})`; x.fillRect(Math.random()*512,Math.random()*512,1,1); }
  x.strokeStyle=vein; x.lineWidth=1.2;
  for(let i=0;i<7;i++){ x.globalAlpha=0.18+Math.random()*0.22; x.beginPath(); let px=Math.random()*512,py=Math.random()*512; x.moveTo(px,py);
    for(let j=0;j<6;j++){ px+=(Math.random()-0.5)*200; py+=(Math.random()-0.5)*200; x.quadraticCurveTo(Math.random()*512,Math.random()*512,px,py);} x.stroke(); }
  x.globalAlpha=1; const t=new THREE.CanvasTexture(c); t.encoding=THREE.sRGBEncoding; t.anisotropy=maxAniso; return t;
}
const matLightTile=new THREE.MeshStandardMaterial({map:marble('#efeadf','#c9b27a'),roughness:.6,metalness:.1});
const matDarkTile =new THREE.MeshStandardMaterial({map:marble('#16161e','#3a3a4c'),roughness:.6,metalness:.1});
// charge tes vraies dalles si elles sont présentes (sinon, garde le marbre)
const TL=new THREE.TextureLoader();
TL.load('assets/tiles/claire.png',t=>{ t.encoding=THREE.sRGBEncoding; t.anisotropy=maxAniso; matLightTile.map=t; matLightTile.needsUpdate=true; });
TL.load('assets/tiles/sombre.png',t=>{ t.encoding=THREE.sRGBEncoding; t.anisotropy=maxAniso; matDarkTile.map=t;  matDarkTile.needsUpdate=true; });

const matSide=new THREE.MeshStandardMaterial({color:0x14141b,roughness:.5,metalness:.55});
const geoTile=new THREE.BoxGeometry(1,EP,1);
const tiles=[];
for(let r=0;r<8;r++)for(let f=0;f<8;f++){
  const light=((r+f)%2===1);                       // a1 (0,0) sombre
  const top=light?matLightTile:matDarkTile;
  const m=new THREE.Mesh(geoTile,[matSide,matSide,top,matSide,matSide,matSide]);
  m.position.set(f-3.5,EP/2,r-3.5); m.receiveShadow=true; m.userData={r,f}; scene.add(m); tiles.push(m);
}
const socle=new THREE.Mesh(new THREE.BoxGeometry(9,0.34,9),new THREE.MeshStandardMaterial({color:0x191921,roughness:.5,metalness:.6}));
socle.position.y=-0.17; socle.receiveShadow=true; scene.add(socle);
const rebord=new THREE.Mesh(new THREE.BoxGeometry(9.4,0.22,9.4),new THREE.MeshStandardMaterial({color:0x6a6a78,roughness:.32,metalness:.9}));
rebord.position.y=-0.36; scene.add(rebord);

/* ---------- Pièces (géométries stylisées — placeholders) ---------- */
const matW=new THREE.MeshStandardMaterial({color:0xe9e3d2,roughness:.45,metalness:.28});
const matB=new THREE.MeshStandardMaterial({color:0x202028,roughness:.42,metalness:.5});
function cyl(rt,rb,h,mat){ return new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,24),mat); }
function sph(r,mat){ return new THREE.Mesh(new THREE.SphereGeometry(r,20,16),mat); }
function part(g,mesh,y){ mesh.position.y=y; mesh.castShadow=true; g.add(mesh); return mesh; }

function makePiece(t,c){
  const mat = c==='w'?matW:matB; const g=new THREE.Group();
  part(g, cyl(0.30,0.34,0.10,mat), 0.05);
  part(g, cyl(0.22,0.30,0.06,mat), 0.13);
  let y=0.16;
  if(t==='p'){
    part(g, cyl(0.12,0.20,0.26,mat), y+0.13); part(g, sph(0.15,mat), y+0.36);
  } else if(t==='r'){
    part(g, cyl(0.18,0.22,0.40,mat), y+0.20); part(g, cyl(0.24,0.20,0.10,mat), y+0.45);
    for(let i=0;i<4;i++){ const b=new THREE.Mesh(new THREE.BoxGeometry(0.08,0.10,0.08),mat); const a=i*Math.PI/2; b.position.set(Math.cos(a)*0.17,y+0.55,Math.sin(a)*0.17); b.castShadow=true; g.add(b); }
  } else if(t==='b'){
    part(g, cyl(0.14,0.22,0.42,mat), y+0.21); part(g, sph(0.17,mat), y+0.50); part(g, sph(0.07,mat), y+0.66);
  } else if(t==='n'){
    part(g, cyl(0.16,0.22,0.30,mat), y+0.15);
    const head=new THREE.Mesh(new THREE.BoxGeometry(0.18,0.30,0.14),mat); head.position.set(0,y+0.46,0.02); head.rotation.x=-0.35; head.castShadow=true; g.add(head);
    const snout=new THREE.Mesh(new THREE.BoxGeometry(0.14,0.12,0.16),mat); snout.position.set(0,y+0.52,0.16); snout.castShadow=true; g.add(snout);
  } else if(t==='q'){
    part(g, cyl(0.16,0.24,0.52,mat), y+0.26);
    const tor=new THREE.Mesh(new THREE.TorusGeometry(0.16,0.04,10,24),mat); tor.rotation.x=Math.PI/2; tor.position.y=y+0.56; tor.castShadow=true; g.add(tor);
    for(let i=0;i<6;i++){ const s=sph(0.05,mat); const a=i*Math.PI/3; s.position.set(Math.cos(a)*0.16,y+0.60,Math.sin(a)*0.16); s.castShadow=true; g.add(s); }
    part(g, sph(0.09,mat), y+0.66);
  } else if(t==='k'){
    part(g, cyl(0.17,0.25,0.56,mat), y+0.28);
    const tor=new THREE.Mesh(new THREE.TorusGeometry(0.17,0.04,10,24),mat); tor.rotation.x=Math.PI/2; tor.position.y=y+0.60; tor.castShadow=true; g.add(tor);
    const v=new THREE.Mesh(new THREE.BoxGeometry(0.06,0.22,0.06),mat); v.position.y=y+0.72; v.castShadow=true; g.add(v);
    const h=new THREE.Mesh(new THREE.BoxGeometry(0.16,0.06,0.06),mat); h.position.y=y+0.72; h.castShadow=true; g.add(h);
  }
  if(c==='b') g.rotation.y=Math.PI;
  return g;
}

/* ---------- État du plateau ---------- */
let board, turn, selected, legal, markers, busy;
const SYM={ w:{k:'♔',q:'♕',r:'♖',b:'♗',n:'♘',p:'♙'}, b:{k:'♚',q:'♛',r:'♜',b:'♝',n:'♞',p:'♟'} };
function pos(r,f){ return new THREE.Vector3(f-3.5, EP, r-3.5); }

function setup(){
  if(board){ for(let r=0;r<8;r++)for(let f=0;f<8;f++){ if(board[r][f]) scene.remove(board[r][f].mesh); } }
  clearMarkers(); selected=null; legal=[]; busy=false; turn='w';
  document.getElementById('prisW').innerHTML=''; document.getElementById('prisB').innerHTML='';
  board=Array.from({length:8},()=>Array(8).fill(null));
  const back=['r','n','b','q','k','b','n','r'];
  for(let f=0;f<8;f++){ add('w',back[f],0,f); add('w','p',1,f); add('b',back[f],7,f); add('b','p',6,f); }
  updateUI();
}
function add(c,t,r,f){ const m=makePiece(t,c); m.position.copy(pos(r,f)); scene.add(m); board[r][f]={t,c,mesh:m}; }

/* ---------- Règles de déplacement ---------- */
const inb=(r,f)=>r>=0&&r<8&&f>=0&&f<8;
function genMoves(r,f){
  const p=board[r][f]; if(!p) return []; const out=[]; const c=p.c;
  const step=(rr,ff)=>{ if(!inb(rr,ff))return; const q=board[rr][ff]; if(q){ if(q.c!==c) out.push({r:rr,f:ff,cap:true}); } else out.push({r:rr,f:ff,cap:false}); };
  const ray=(dr,df)=>{ let rr=r+dr,ff=f+df; while(inb(rr,ff)){ const q=board[rr][ff]; if(!q) out.push({r:rr,f:ff,cap:false}); else { if(q.c!==c) out.push({r:rr,f:ff,cap:true}); break; } rr+=dr; ff+=df; } };
  if(p.t==='p'){ const d=c==='w'?1:-1; const start=c==='w'?1:6;
    if(inb(r+d,f)&&!board[r+d][f]){ out.push({r:r+d,f:f,cap:false}); if(r===start&&!board[r+2*d][f]) out.push({r:r+2*d,f:f,cap:false}); }
    [[d,-1],[d,1]].forEach(([dr,df])=>{ const rr=r+dr,ff=f+df; if(inb(rr,ff)&&board[rr][ff]&&board[rr][ff].c!==c) out.push({r:rr,f:ff,cap:true}); });
  } else if(p.t==='r'){ [[1,0],[-1,0],[0,1],[0,-1]].forEach(d=>ray(d[0],d[1]));
  } else if(p.t==='b'){ [[1,1],[1,-1],[-1,1],[-1,-1]].forEach(d=>ray(d[0],d[1]));
  } else if(p.t==='q'){ [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]].forEach(d=>ray(d[0],d[1]));
  } else if(p.t==='n'){ [[1,2],[2,1],[-1,2],[-2,1],[1,-2],[2,-1],[-1,-2],[-2,-1]].forEach(d=>step(r+d[0],f+d[1]));
  } else if(p.t==='k'){ [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]].forEach(d=>step(r+d[0],f+d[1])); }
  return out;
}

/* ---------- Marqueurs ---------- */
const geoDot=new THREE.CylinderGeometry(0.12,0.12,0.02,20);
const geoRing=new THREE.TorusGeometry(0.40,0.045,10,28);
const matMove=new THREE.MeshStandardMaterial({color:0x6fe39a,emissive:0x2f7d50,roughness:.4,transparent:true,opacity:.9});
const matCap=new THREE.MeshStandardMaterial({color:0xff5470,emissive:0x7a2236,roughness:.4});
const matSel=new THREE.MeshStandardMaterial({color:0xc8a85a,emissive:0x6b5320,roughness:.35});
function clearMarkers(){ if(markers) markers.forEach(m=>scene.remove(m)); markers=[]; }
function showMarkers(){
  clearMarkers();
  if(selected){ const ring=new THREE.Mesh(geoRing,matSel); ring.rotation.x=Math.PI/2; const p=pos(selected.r,selected.f); ring.position.set(p.x,EP+0.02,p.z); scene.add(ring); markers.push(ring); }
  legal.forEach(m=>{ const p=pos(m.r,m.f);
    if(m.cap){ const r=new THREE.Mesh(geoRing,matCap); r.rotation.x=Math.PI/2; r.position.set(p.x,EP+0.02,p.z); scene.add(r); markers.push(r); }
    else { const d=new THREE.Mesh(geoDot,matMove); d.position.set(p.x,EP+0.012,p.z); scene.add(d); markers.push(d); } });
}

/* ---------- Animations ---------- */
const anims=[];
const ease=p=>p<0.5?2*p*p:1-Math.pow(-2*p+2,2)/2;
function animMove(mesh,r1,f1,onDone){ const x0=mesh.position.x,z0=mesh.position.z; const p1=pos(r1,f1);
  anims.push({t:0,dur:0.55,upd(p){ const e=ease(p); mesh.position.x=x0+(p1.x-x0)*e; mesh.position.z=z0+(p1.z-z0)*e; mesh.position.y=EP+Math.sin(p*Math.PI)*0.33; },done(){ mesh.position.y=EP; onDone&&onDone(); }}); }
function animCapture(mesh,onDone){ mesh.traverse(o=>{ if(o.material){ o.material=o.material.clone(); o.material.transparent=true; } });
  anims.push({t:0,dur:0.45,upd(p){ const s=Math.max(0.001,1-p); mesh.scale.setScalar(s); mesh.position.y=EP-p*0.45; mesh.traverse(o=>{ if(o.material) o.material.opacity=1-p; }); },done(){ scene.remove(mesh); onDone&&onDone(); }}); }

/* ---------- Coups ---------- */
function select(r,f){ selected={r,f}; legal=genMoves(r,f); showMarkers(); }
function deselect(){ selected=null; legal=[]; showMarkers(); }
function doMove(r0,f0,r1,f1){
  busy=true; clearMarkers();
  const piece=board[r0][f0], target=board[r1][f1];
  if(target){ pushPris(target); animCapture(target.mesh); }
  animMove(piece.mesh,r1,f1,()=>{
    board[r1][f1]=piece; board[r0][f0]=null;
    if(piece.t==='p' && ((piece.c==='w'&&r1===7)||(piece.c==='b'&&r1===0))) promote(piece,r1,f1);
    selected=null; legal=[]; turn=turn==='w'?'b':'w'; busy=false; updateUI();
  });
}
function promote(piece,r,f){ scene.remove(piece.mesh); const m=makePiece('q',piece.c); m.position.copy(pos(r,f)); scene.add(m); piece.mesh=m; piece.t='q'; }
function pushPris(p){ const span=document.createElement('span'); span.textContent=SYM[p.c][p.t];
  span.style.color = p.c==='w' ? '#efe9da' : '#23232e'; span.style.textShadow = p.c==='b' ? '0 0 2px rgba(255,255,255,.5)':'none';
  document.getElementById(p.c==='w'?'prisB':'prisW').appendChild(span); }

/* ---------- Interaction (tap-to-move + orbite) ---------- */
const ray=new THREE.Raycaster(), ndc=new THREE.Vector2();
function tapSquare(cx,cy){ const rct=renderer.domElement.getBoundingClientRect();
  ndc.x=((cx-rct.left)/rct.width)*2-1; ndc.y=-((cy-rct.top)/rct.height)*2+1;
  ray.setFromCamera(ndc,camera); const hit=ray.intersectObjects(tiles,false);
  if(hit.length) handleTap(hit[0].object.userData.r, hit[0].object.userData.f); }
function handleTap(r,f){
  if(busy) return; const cell=board[r][f];
  if(selected){ const mv=legal.find(m=>m.r===r&&m.f===f); if(mv){ doMove(selected.r,selected.f,r,f); return; } }
  if(cell && cell.c===turn){ if(selected&&selected.r===r&&selected.f===f) deselect(); else select(r,f); }
  else deselect();
}

const cible=new THREE.Vector3(0,0.3,0); const DEP={theta:Math.PI,phi:0.92,radius:11};
let theta=DEP.theta,phi=DEP.phi,radius=DEP.radius;
function placeCam(){ camera.position.set(cible.x+radius*Math.sin(phi)*Math.sin(theta),cible.y+radius*Math.cos(phi),cible.z+radius*Math.sin(phi)*Math.cos(theta)); camera.lookAt(cible); }
placeCam();
const dom=renderer.domElement, pts=new Map(); let last=null,pinch=0,rBase=0,downAt=null,moved=0;
const dist=()=>{ const p=[...pts.values()]; return Math.hypot(p[0].x-p[1].x,p[0].y-p[1].y); };
dom.addEventListener('pointerdown',e=>{ dom.setPointerCapture(e.pointerId); pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pts.size===1){ last={x:e.clientX,y:e.clientY}; downAt={x:e.clientX,y:e.clientY}; moved=0; } else if(pts.size===2){ pinch=dist(); rBase=radius; last=null; } });
dom.addEventListener('pointermove',e=>{ if(!pts.has(e.pointerId))return; pts.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(pts.size===2){ const d=dist(); if(pinch>0){ radius=Math.min(20,Math.max(5,rBase*pinch/d)); placeCam(); } }
  else if(pts.size===1&&last){ const dx=e.clientX-last.x,dy=e.clientY-last.y; moved+=Math.abs(dx)+Math.abs(dy);
    theta-=dx*0.005; phi=Math.max(0.25,Math.min(1.4,phi-dy*0.005)); last={x:e.clientX,y:e.clientY}; placeCam(); } });
function up(e){ const was=pts.size; pts.delete(e.pointerId);
  if(was===1 && downAt && moved<8){ tapSquare(downAt.x,downAt.y); }
  if(pts.size===1){ const p=[...pts.values()][0]; last={x:p.x,y:p.y}; pinch=0; } else if(pts.size===0){ last=null; pinch=0; } downAt=null; }
dom.addEventListener('pointerup',up); dom.addEventListener('pointercancel',up);
dom.addEventListener('wheel',e=>{ e.preventDefault(); radius=Math.min(20,Math.max(5,radius+e.deltaY*0.012)); placeCam(); },{passive:false});

/* ---------- UI ---------- */
function updateUI(){ document.getElementById('tourtxt').textContent = turn==='w'?'Aux Blancs':'Aux Noirs';
  document.getElementById('pastille').style.background = turn==='w'?'#efe9da':'#23232e'; }
document.getElementById('reset').onclick=setup;
let aideOff=false;
addEventListener('resize',()=>{ camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth,innerHeight); });

/* ---------- Boucle ---------- */
function loop(){ requestAnimationFrame(loop); const dt=Math.min(clock.getDelta(),0.05);
  for(let i=anims.length-1;i>=0;i--){ const a=anims[i]; a.t+=dt; const p=Math.min(1,a.t/a.dur); a.upd(p); if(p>=1){ a.done&&a.done(); anims.splice(i,1); } }
  if(!aideOff && (selected||busy)){ aideOff=true; const el=document.getElementById('aide'); if(el){ el.style.opacity=0; setTimeout(()=>el.remove(),600); } }
  renderer.render(scene,camera);
}
setup(); loop();
